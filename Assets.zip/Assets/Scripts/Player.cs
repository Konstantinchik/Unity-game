﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    // Start is called before the first frame update
    //void Start()
    //{
    //    
    //}

    // Update is called once per frame
    //void Update()
    //{
    //    
    //}

    public GameObject restart; // handling of restart button
    
    public static bool loose = false; //  static - accessed everywear in programm!!!

    void Awake() // called before level start for Reset "LOOSE" variable
    {
        loose = false;
    }

    void OnTriggerEnter2D(Collider2D other)  // Work when Objet hit another Object
    {
        if(other.gameObject.tag == "Bomb")
        {
            loose = true;
            restart.SetActive(true); // activate Restart button
        }
    }
}
