﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class MovePlayer : MonoBehaviour
{
    // Start is called before the first frame update
 //   void Start()
 //   {
 //       
 //   }
 //
    // Update is called once per frame
 //   void Update()
 //   {
 //       
 //   }

    // class UnityEngine.Transform - position, rotation, scale object 
    public Transform player;

    [SerializeField] // make Private seen in Unity
    private float speed = 10f; // private variables for our internal purpuse

    // MovePlayer.OnMouseDrag()
    void OnMouseDrag()
    {
        if (!Player.loose) // until we are not loose
        {
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            // restriction of X-Axis movement
            //if mousePos.x > 2.5 then mousePos.x = 2.5 else mousePos.x = mousePos.x
            mousePos.x = mousePos.x > 2.5f ? 2.5f : mousePos.x; // right restriction

            mousePos.x = mousePos.x < -2.5f ? -2.5f : mousePos.x; // left restriction

            player.position = Vector2.MoveTowards(player.position,
                new Vector2(mousePos.x, player.position.y),
                speed * Time.deltaTime); // current, targer, maxDistanceDelta
        }
    }
}
