﻿using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class SpawnBombs : MonoBehaviour
{

    public GameObject bomb; // Bomb-object wich we will clone

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Spawn()); // Starting spawning...
    }

    // Update is called once per frame
    //void Update()
    //{
    //    
    //}

    IEnumerator Spawn()
    {
        while(!Player.loose) // infinity loop -while(false)
        {
            // create bombs in dedicated range in identity rotation (as is)
            Instantiate(bomb, new Vector2(Random.Range(-2.5f, 2.5f), 5.9f), Quaternion.identity);
            // respawn after 1.5 seconds
            yield return new WaitForSeconds(0.8f); // !!! YIELD NEW THREAD multithreading

        }
    }
}
